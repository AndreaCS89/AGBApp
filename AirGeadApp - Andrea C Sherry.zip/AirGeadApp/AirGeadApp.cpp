// Name: Andrea Carmen Sherry

#include <iostream>
#include <iomanip>

using namespace std;

int main() //First, declare variables.
{
	//Declare variables that will store input information.
	float initInv, monDep, AnuInt, months, years;
	//Declare variables that will store end-year information.
	float totalAm, intAmt, yearTotInt;


	//Display Data Input Menu.
	cout << "********************************\n";
	cout << "********** Data Input **********\n";
	cout << "Initial Investment Amount: \n";
	cout << "Monthly Deposit: \n";
	cout << "Annual Interest: \n";
	cout << "Number of years: \n";

	//Input User.
	system("PAUSE");

	//Display Data Input Menu and get data from user.
	cout << "********************************\n";
	cout << "********** Data Input **********\n";
	cout << "Initial Investment Amount: $";
	cin >> initInv;
	cout << "Monthly Deposit: $";
	cin >> monDep;
	cout << "Annual Interest: %";
	cin >> AnuInt;
	cout << "Number of years: ";
	cin >> years;
	months = years * 12;

	//Input User.
	system("PAUSE");

	//Update previous investment information with new total amount.
	totalAm = initInv;

	//Display year-end data WITHOUT monthly deposits.
	cout << "\nBalance and Interest Without Additional Monthly Deposits\n";
	cout << "==============================================================\n";
	cout << "Year\t\tYear End Balance\tYear End Earned Interest\n";
	cout << "--------------------------------------------------------------\n";


	for (int i = 0; i < years; i++) { //Begin Calculations.

		//Yearly Interest.
		intAmt = (totalAm) * ((AnuInt / 100));

		//Total Year-end.
		totalAm = totalAm + intAmt;

		//Show result to the report.
		cout << (i + 1) << "\t\t$" << fixed << setprecision(2) << totalAm << "\t\t\t$" << intAmt << "\n";

	}

	//Update Total Amount to Initial Investment.
	totalAm = initInv;

	//Display year data WITH monthly deposits.
	cout << "\n\nBalance and Interest With Additional Monthly Deposits\n";
	cout << "==============================================================\n";
	cout << "Year\t\tYear End Balance\tYear End Earned Interest\n";
	cout << "--------------------------------------------------------------\n";

	for (int i = 0; i < years; i++) {

		//Interest set to 0 at the begining of the year.
		yearTotInt = 0;

		for (int j = 0; j < 12; j++) { //Begin calculations.

			//Monthly interest.
			intAmt = (totalAm + monDep) * ((AnuInt / 100) / 12);

			//Month end interest.
			yearTotInt = yearTotInt + intAmt;

			//Month end total.
			totalAm = totalAm + monDep + intAmt;

		}

		//Display results to the report.
		cout << (i + 1) << "\t\t$" << fixed << setprecision(2) << totalAm << "\t\t\t$" << yearTotInt << "\n";
	}

	return 0;
}
